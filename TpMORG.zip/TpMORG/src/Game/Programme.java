package Game;

import Personnage.Pj;

public class Programme {

	public static void main(String[] args) {
		Pj perso;
		Partie p;
		// if (! sauvegarde)
		perso = null;/* new perso */
		p = new Partie();
		if (p.demarrer(perso)) {

			System.out.println("gagn�)");
		} else {
			System.out.println("perdu");
		}
	}
}