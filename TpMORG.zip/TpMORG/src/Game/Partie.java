package Game;

import java.util.Scanner;

import Personnage.Monstre;
import Personnage.Pj;
import Rencontre.Rencontre;
import Rencontre.UtilitaireRegles;

public class Partie {

	private int nbTours = 1;

	public boolean demarrer(Pj perso) {
		while (this.nbTours < 16 && perso.isEnVie()) {

			this.deroulerTour(perso);
			this.nbTours++;
		}
		return perso.isEnVie();
	}

	private void deroulerTour(Pj perso) {

		int tirage = UtilitaireRegles.pickADice(100);

		System.out.println("Vous �tes au tour " + nbTours);
		System.out.println("Souhaitez vous continuer votre route ?( o (oui) / n (non))");
		Scanner sc = new Scanner(System.in);
		String continuer = sc.nextLine();
		switch (continuer) {
		case "o":
			if (tirage <= 70) {
				System.out.println("Vous rencontrez un monstre sur votre chemin...Le combat commence!");
				Monstre monMonstre = new Monstre();
				Rencontre.combat(perso, monMonstre);
			} else if (tirage > 70 && tirage <= 90) {
				perso.coach();
			} else {
				perso.healer();
			}
			break;
		case "n":
			System.out.println("Etes vous s�r ? (o (oui) / n (non)");
			Scanner sc1 = new Scanner(System.in);
			String continuer1 = sc.nextLine();
			switch (continuer1) {
			case "o":
				perso.pv = 0;
				break;
			case "n":
				break;
			default:
				System.out.println("Je vous sens ind�cis...");
				break;
			}
		default:
			System.exit(0);
		}
	}
}