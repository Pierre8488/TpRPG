package Rencontre;

public class UtilitaireRegles {

	public static int pickADice(int diceMaxVal) {
		double d100 = Math.random() * 100.0 + 1;
		return (int) Math.round(d100 * (double) diceMaxVal / 100.0);
	}
}
