package Rencontre;

import Personnage.Monstre;
import Personnage.Pj;
import java.util.Scanner;

public class Rencontre {
	public static boolean combat(Pj joueur, Monstre monstre) {
		while (joueur.isEnVie() && monstre.isEnVie()) {
			System.out
					.println("Choix de l'attaque : Tapez '1' pour une attaque physique ou '2' pour une attaque magique");
			Scanner sc = new Scanner(System.in);
			String typeAttaque = sc.nextLine();
			switch (typeAttaque) {
			case "1":
				int degatsJoueur1 = joueur.attaquePhysique();
				monstre.encaisserDegats(degatsJoueur1);
				System.out.println("Vous avez fait " + degatsJoueur1 + " de d�gats au monstre.");
				break;

			case "2":
				int degatsJoueur2 = joueur.attaqueMagique();
				monstre.encaisserDegats(degatsJoueur2);
				System.out.println("Vous avez fait " + degatsJoueur2 + " de d�gats au monstre.");

				break;
			default:
				System.out.println("Vous avez manqu� votre attaque...");
				break;
			}
			if(monstre.isEnVie()) {
				System.out.println("Le monstre passe � l'attaque!");
				int degatsMonstre = monstre.attaque();
				joueur.encaisserDegats(degatsMonstre);
				System.out.println("Le monstre a fait " + degatsMonstre + " de d�gats au joueur.");
			}
				else 
			System.out.println("Le monstre sucombe a ses blessures...");
			
		}

		if (joueur.isEnVie()) {
			System.out.println("Vous avez gagn� votre combat");
			joueur.gainXp();
			joueur.augmenterNiveau();
			joueur.afficheStats();
			return true;

		} else {
			System.out.println("Le monstre a gagn� le combat");
			return false;
		}

	}
}
