package Personnage;

public class Mage extends Pj {

	private static final int forceBase = 6;
	private static final int agiliteBase = 6;
	private static final int intelligenceBase = 10;
	private static final int pvBase = 200;

	public Mage(String Pseudonyme) {
		super("Mage", forceBase, agiliteBase, intelligenceBase, 200, pvBase, (float)1.06, 2, 1, 5, 0, 5);

	}
}
