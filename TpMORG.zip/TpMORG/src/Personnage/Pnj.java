package Personnage;

public abstract class Pnj {

	public void Copiner(Pj perso) {
		// TODO Auto-generated method stub
		
	}

}
