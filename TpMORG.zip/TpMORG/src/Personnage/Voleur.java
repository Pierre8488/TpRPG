package Personnage;

public class Voleur extends Pj {

	private static final int forceBase = 8;
	private static final int agiliteBase = 10;
	private static final int intelligenceBase = 8;
	private static final int pvBase = 250;

	public Voleur(String Pseudonyme) {
		super("Voleur", forceBase, agiliteBase, intelligenceBase, 300, pvBase, (float)1.08, 2, 3, 2, 0, 5);

	}
}
