package Personnage;

public abstract class Pj {

	// Caract�ristiques de tout les persos

	private String name;
	private int force;
	private int agilite;
	private int intelligence;
	public int pv;
	private int pvMax;
	private int niveau = 1;
	public int xp = 0;
	public int xpNecessaire = 1;
	private int degatsPhysique;
	private int degatsMagique;
	

	// Caract�ristiques lorsque niveau augmente
	private float pvParLvl;
	private int forceParLvl;
	private int agiliteParLvl;
	private int intellParLvl;

	public Pj(String name, int force, int agilite, int intelligence, int pv, int pvMax, float pvParLvl, int forceParLvl, int agiliteParLvl, int intellParLvl, int xp, int xpNecessaire) {
		super();
		this.name = name;
		this.force = force;
		this.agilite = agilite;
		this.intelligence = intelligence;
		this.pv = pv;
		this.pvMax = pvMax;
		this.pvParLvl = pvParLvl;
		this.forceParLvl = forceParLvl;
		this.agiliteParLvl = agiliteParLvl;
		this.intellParLvl = intellParLvl;
	}

	// Methode Get
	public String getName() {
		return name;
	}

	public int getForce() {
		return force;
	}

	public void afficheStats() {
	System.out.println("Pj [force=" + force + ", agilite=" + agilite + ", intelligence=" + intelligence + ", pv=" + pv
				+ ", pvMax=" + pvMax + ", xp=" + xp + ", xpNecessaire=" + xpNecessaire + ", degatsPhysique="
				+ degatsPhysique + ", degatsMagique=" + degatsMagique + "]");
	}

	public int getAgilit�() {
		return agilite;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public int getPv() {
		return pv;
	}

	public int getPvMax() {
		return pvMax;
	}

	public int getNiveau() {
		return niveau;
	}

	public int getXp() {
		return xp;
	}

	public int getXpNecessaire() {
		return xpNecessaire;
	}

	public int getPvParLvl() {
		return (int) pvParLvl;
	}

	public int getForceParLvl() {
		return forceParLvl;
	}

	public int getAgiliteParLvl() {
		return agiliteParLvl;
	}

	public int getIntellParLvl() {
		return intellParLvl;
		
	}
	public boolean isEnVie() {
		if (pv>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void gainXp() {
		xp = xp + 1;
	}
	
	public boolean augmenterNiveau() {
		if (xp >= xpNecessaire) {
			force = force + forceParLvl;
			agilite = agilite  + agiliteParLvl;
			intelligence = intelligence + intellParLvl;
			pvMax = (int)(pvMax * pvParLvl);
			pv = pvMax;
			niveau++;
			System.out.println("Vous passez au niveau sup�rieur, vous �tes d�sormais au niveau " + getNiveau());
			xp = 0;
			int xpMoinsUnNiveau;
			int xpMoinsDeuxNiveau = 0;
			int xpNouveau;
			xpMoinsUnNiveau = xpNecessaire;
			xpNouveau = xpMoinsDeuxNiveau + xpMoinsUnNiveau;
			xpMoinsDeuxNiveau = xpNouveau;
			xpNecessaire = xpNouveau;
			return true;
		}
		return false;
	}
	public void healer() {
		pv += pvMax * 25 / 100;
		if (pv > pvMax) {
			pv = pvMax;
		}
		System.out.println("Vous rencontrez le m�decin, vous r�cuperez une partie de vos pv");
	}

	public void coach() {
		System.out.println("Vous rencontrez J�r�me le coach sportif");
		force = force + forceParLvl;
		agilite = agilite  + agiliteParLvl;
		intelligence = intelligence + intellParLvl;
		pvMax = (int)(pvMax * pvParLvl);
		pv = pvMax;
		niveau++;
		System.out.println("Vous passez au niveau sup�rieur, vous �tes d�sormais au niveau " + getNiveau());
	}
	public int attaquePhysique() {
		degatsPhysique = force;
		return degatsPhysique;
	}
	
	public int attaqueMagique() {
		degatsMagique = intelligence;
		return degatsMagique;
	}

	public void encaisserDegats(int degats) {
    	pv = pv - degats;
    }
}
