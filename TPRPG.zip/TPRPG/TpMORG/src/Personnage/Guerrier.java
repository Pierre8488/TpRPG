package Personnage;

public class Guerrier extends Pj {

	private static final int forceBase = 10;
	private static final int agiliteBase = 8;
	private static final int intelligenceBase = 6;
	private static final int pvBase = 300;

	public Guerrier(String Pseudonyme) {
		super("Guerrier", forceBase, agiliteBase, intelligenceBase, 300, pvBase, (float) 1.1, 4, 2, 1, 0, 5);

	}

}
