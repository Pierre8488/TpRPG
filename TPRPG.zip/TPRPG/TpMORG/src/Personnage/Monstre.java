package Personnage;

public class Monstre{

    private static int pvMaxMonstre =25;
    private int pvActuelsMonstre=pvMaxMonstre;

    	public boolean isEnVie() {
    		if (pvActuelsMonstre>0) {
    			return true;
    		}
    		else {
    			return false;
    		}
    	
    }

    public Monstre() {
     
        if (pvActuelsMonstre < 0) {
            this.pvActuelsMonstre = 0;
        }
    }


   /* public int encaisserDegatsMagiques(int ptsDegats, Monstre monstre) {
        pvActuelsMonstre -= ptsDegats;
        System.out.println("Le monstre subit " + ptsDegats + " points de d�g�ts");
        return pvActuelsMonstre;
    }

    public int encaisserDegatsPhysiques(int ptsDegats, Monstre monstre) {
        pvActuelsMonstre -= ptsDegats;
        System.out.println("Le monstre subit " + ptsDegats + " points de d�g�ts");
        return pvActuelsMonstre;
    }*/
    
    public int attaque() {
    	return 5; // Calculer degats a faire plus tard
    }
    
    public void encaisserDegats(int degats) {
    	pvActuelsMonstre = pvActuelsMonstre - degats;
    }
    }
