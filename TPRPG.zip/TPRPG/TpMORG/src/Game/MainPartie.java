package Game;

import java.util.Scanner;

import Personnage.Guerrier;
import Personnage.Mage;
import Personnage.Pj;
import Personnage.Voleur;

public class MainPartie {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		System.out.println("Entrez un Pseudonyme : ");
		Scanner sc = new Scanner(System.in);
		String Pseudonyme = sc.nextLine();
		System.out.println("Votre pseudonyme est : " + Pseudonyme);
		System.out.println("Choisissez une classe de personnage : Guerrier , Voleur, Mage");
		Scanner sc1 = new Scanner(System.in);
		String ClassePersonnage = sc.nextLine();
		System.out.println("Votre personnage est de classe : " + ClassePersonnage);

		Pj joueur;
		switch (ClassePersonnage) {
		case "Guerrier":
			joueur = new Guerrier(Pseudonyme);
			break;
		case "Mage":
			joueur = new Mage(Pseudonyme);
			break;
		case "Voleur":
			joueur = new Voleur(Pseudonyme);
			break;
			default :
				joueur = new Voleur(Pseudonyme);
				System.exit(1);
				break;
		}
		Partie NouvellePartie = new Partie(); 
			NouvellePartie.demarrer(joueur);
		
		
	}
}